import React from 'react'

const SuperAdminDashboard = () => {
  return (
    <div>
        
    </div>
  )
}

export default SuperAdminDashboard