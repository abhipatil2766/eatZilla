import React from 'react'
import RestaurantTable from './RestaurantTable'

const SuperAdminRestaurant = () => {
  return (
    <div>
        <RestaurantTable name={"All Restaurants"}/>
    </div>
  )
}

export default SuperAdminRestaurant