package com.eatzilla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EatzillaFoodApplication {

	public static void main(String[] args) { 
		SpringApplication.run(EatzillaFoodApplication.class, args);
	}

}
