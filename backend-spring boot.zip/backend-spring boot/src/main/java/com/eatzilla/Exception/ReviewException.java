package com.eatzilla.Exception;

public class ReviewException extends Exception {

	public ReviewException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
