package com.eatzilla.service;

import java.util.List;

import com.eatzilla.model.Notification;
import com.eatzilla.model.Order;
import com.eatzilla.model.Restaurant;
import com.eatzilla.model.User;

public interface NotificationService {
	
	public Notification sendOrderStatusNotification(Order order);
	public void sendRestaurantNotification(Restaurant restaurant, String message);
	public void sendPromotionalNotification(User user, String message);
	
	public List<Notification> findUsersNotification(Long userId);

}
