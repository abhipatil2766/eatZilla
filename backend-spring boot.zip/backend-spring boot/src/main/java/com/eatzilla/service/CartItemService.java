package com.eatzilla.service;

import com.eatzilla.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
