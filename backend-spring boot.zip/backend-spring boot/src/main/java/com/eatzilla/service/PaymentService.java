package com.eatzilla.service;

import com.eatzilla.model.Order;
import com.eatzilla.model.PaymentResponse;
import com.stripe.exception.StripeException;

public interface PaymentService {
	
	public PaymentResponse generatePaymentLink(Order order) throws StripeException;

}
