package com.eatzilla.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eatzilla.model.Events;

public interface EventRepository extends JpaRepository<Events, Long>{

	public List<Events> findEventsByRestaurantId(Long id);
}
