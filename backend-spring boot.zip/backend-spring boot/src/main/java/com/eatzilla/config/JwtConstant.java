package com.eatzilla.config;

public class JwtConstant {


//	public static final String SECRET_KEY="wpembytrwcvnryxksdbqwjebruyGHyudqgwveytrtrCSnwifoesarjbwe";
	public static final String SECRET_KEY="3cfa76ef14937c1c0ea519f8fc057a80fcd04a7420f8e8bcd0a7567c272e007b";
	public static final String JWT_HEADER="Authorization";
	
}
